CREATE TABLE `twibber_entry` (
`nickname` VARCHAR( 40 ) NOT NULL ,
`text` TEXT NOT NULL ,
`date` VARCHAR( 50 ) NOT NULL
)